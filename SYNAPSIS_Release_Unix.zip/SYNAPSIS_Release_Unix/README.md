# Synapsis
Virtual Assistant written in C++ to work in the console.
